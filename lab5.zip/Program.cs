﻿using System;
using System.Collections.Generic;

namespace task5
{
    class Program
    {
        static void Main(string[] args)
        {
            User user = new User();
        }
    }


    class Texture
    {
        public int Num { get; set; }
    }



    class Solger
    {
        public Texture textur;

        public Solger(Texture textur)
        {
            this.textur = textur;
            //как-то записываем сюда текстуры
        }

    }


    class Unit
    {
        double x;
        double y;
        int hp;
        Solger sol;
        public Unit(double x, double y, int hp, Solger sol)
        {
            this.x = x;
            this.y = y;
            this.hp = hp;
            this.sol = sol;
        }
        /// <summary>
        /// Отображает информацию об текстуре, как бы рисует
        /// </summary>
        public void Draw()
        {
            Console.WriteLine("Нарисован с текстурой "+ sol.textur.Num);
        }
    }



    class UnitFactory
    {
        static List<Solger> solgers= new List<Solger>();
        /// <summary>
        /// Производит проверку, есть ли такой тип солдата
        /// </summary>
        /// <param name="sol"> Получает солдата, для текстуры</param>
        /// <returns>Возвращает -1, если такого нет или его индекс в листе</returns>
        static int Comp(Solger sol)
        {
            int i = 0;
            foreach(Solger solger in solgers)
            {

                if (solger.textur.Num == sol.textur.Num)
                    return i;
                i++;
            }
            return -1;
        }
        /// <summary>
        /// Предоставляет экзепляр класса(готовый юнит)
        /// </summary>
        /// <param name="x">х-овая координата положения</param>
        /// <param name="y">у-овая координата положения</param>
        /// <param name="hp">хп юнита</param>
        /// <param name="textur">Текстура юнита</param>
        /// <returns>Возвращает юнита.</returns>
        public static Unit GetUnit(double x, double y, int hp, Texture textur)
        {
            int s = Comp(new Solger(textur));
            if(s<0)
            {
                solgers.Add(new Solger(textur));
                return new Unit(x,y,hp,solgers[solgers.Count - 1]);
            }

            return new Unit(x, y, hp, solgers[s]); 

        }
    }


    class User
    {

        public User()
        {
            Texture tex1 = new Texture();
            tex1.Num=1;
            Texture tex2 = new Texture();
            tex2.Num = 2;
            Texture tex3 = new Texture();
            tex3.Num = 3;
            List<Unit> u = new List<Unit>();

            Dictionary<int, Texture> d = new Dictionary<int, Texture> { {  0, tex1 }, { 1, tex2}, { 2, tex3} };


            Console.WriteLine("Введите ко-во юнитов");
            Create(u,d);

        }
        /// <summary>
        /// Заполняет лист экземплярами с разными текстурами и рисует их
        /// </summary>
        /// <param name="u">Лист юнитов</param>
        /// <param name="d">Словарь с текстурами</param>
        void Create(List<Unit> u, Dictionary<int, Texture> d)
        {
            try
            {
                int N = Convert.ToInt32(Console.ReadLine());
                if (N > 1000000)
                    throw new Exception();
                for (int i = 0; i < N; i++)
                {
                    u.Add(UnitFactory.GetUnit(3, 3, 3, d[i % 3]));
                }
                for (int i = 0; i < N; i++)
                {
                    u[i].Draw();
                }
            }
            catch
            {
                Console.WriteLine("Данные введены неверно, попробуйте еще раз");
                Create(u,d);
            }
        }


    }


}
